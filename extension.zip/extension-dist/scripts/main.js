/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';
	/*global chrome*/

	function loadWidget() {

		// add the widget stylesheet
		__webpack_require__(1);

		const holder = document.createElement('div');
		const close = document.createElement('span');
		const refresh = document.createElement('span');
		const textTarget = document.createElement('div');
		const myUrl = window.location.href;

		function removeSelf (){
			holder.parentNode.removeChild(holder);
			chrome.runtime.onMessage.removeListener(recieveData);
		}

		function getData (url, fresh) {
			fresh = fresh || false;
			chrome.runtime.sendMessage({
				method: 'getData',
				url : url,
				fresh : fresh
			});
		}

		function recieveData (request) {
			if (open && request.method === 'updateData' && request.url === myUrl){
				const data = request.data;
				let output = '';

				data.forEach(datum => {
					output += `<h3>${datum.category}</h3><div class="insights"><h4>${datum.provider}</h4>`;
					datum.comparisons.forEach(comparison => {
						output += `<li class="ok-${ comparison.ok }"><a href="${datum.link}" target="_blank">${comparison.text}</a></li>`;
					});
					output += '</div>';

				});

				textTarget.innerHTML = output;
			}
		}

		function refreshFn () {
			textTarget.innerHTML = waitingText;
			getData(myUrl, true);
		}

		// prepare to recieve data.
		chrome.runtime.onMessage.addListener(recieveData);

		// ask for the data to be updated
		getData(myUrl);


		const waitingText = 'Loading Analysis...';
		textTarget.innerHTML = waitingText;
		holder.appendChild(textTarget);
		holder.appendChild(close);
		holder.appendChild(refresh);

		close.setAttribute('class', 'close');
		close.addEventListener('click', removeSelf, false);

		refresh.setAttribute('class', 'refresh');
		refresh.addEventListener('click', refreshFn, false);

		holder.setAttribute('id', 'perf-widget-holder');
		document.body.appendChild(holder);

		return {
			close: removeSelf,
			refresh: refreshFn
		}
	}

	let widgetControls;

	chrome.runtime.sendMessage({method: 'isEnabled'}, response => {
		if (response.enabled && location.hostname.match(/ft.com$/)) widgetControls = loadWidget();
	});

	chrome.runtime.onMessage.addListener(function (request) {
		if (request.method === 'showWidget'){
			if (widgetControls) {
				widgetControls.refresh();
			} else {
				widgetControls = loadWidget();
			}
		}
	});


/***/ },
/* 1 */
/***/ function(module, exports) {

	
	const style = document.createElement('style');
	const serviceURL = 'https://ftlabs-perf-widget-test.herokuapp.com';

	style.textContent = `

		#perf-widget-holder {
			all: initial;
		}

		#perf-widget-holder > * {
			all: unset;
		}

		#perf-widget-holder {
			position: fixed;
			bottom : 20px;
			right : 20px;
			width : 250px;
			max-height : 300px;
			overflow-y: auto;
			background-color : #333;
			z-index : 2147483647;
			border-radius: 5px;
			box-shadow: 0 0 5px black;
			color: white;
			box-sizing: border-box;
			padding: 10px;
			font-size: 14px;
			padding-bottom: 20px;
			font-family: Helvetica, Arial, sans-serif;
		}

		#perf-widget-holder > *{
			font-weight: 100;
		}

		#perf-widget-holder .close{
			position: absolute;
			right: 5px;
			top: 5px;
			color: rgba(255,255,255,.5);
			border: 1px solid white;
			width: 1em;
			height: 1em;
			text-align: center;
			border-radius: 100%;
			cursor: pointer;
			background-size: 50%;
			background-position: 50%;
			background-repeat: no-repeat;
			background-image: url('${serviceURL}/static/images/cross.png');
		}

		#perf-widget-holder .refresh{
			position: absolute;
			right: 30px;
			top: 5px;
			color: rgba(255,255,255,.5);
			// border: 1px solid white;
			width: 1em;
			height: 1em;
			text-align: center;
			border-radius: 100%;
			cursor: pointer;
			background-size: 80%;
			background-position: 50%;
			background-repeat: no-repeat;
			background-image: url('${serviceURL}/static/images/refresh.png');
		}

		#perf-widget-holder h3:first-of-type{
			margin-top:0;
		}

		#perf-widget-holder h3{
			margin-top: 10px;
			display: block;
		}

		#perf-widget-holder .insights{
			padding-left: 10px;
		    display: block;
		    margin-top: 5px;
		}

		#perf-widget-holder .insights h4{
			font-size: 0.8em;
			margin-top: 0;
			margin-bottom : 0.3em;
		}

		#perf-widget-holder .insights li{
			list-style-type: none;
			padding: 0;
			margin: 0;
			font-size: 0.8em;
			width: 90%;
			margin-left: 10%;
			display: inline-block;
		}

		#perf-widget-holder .insights li::before{
			width: 1em;
			height: 1em;
			display: inline-block;
			content: "";
			margin-right: 0.5em;
			background-size: 100%;
			padding-top: 2px;
			background-position: 50%;
			background-repeat: no-repeat;
			background-image: url('${serviceURL}/static/images/unsure.png');
			position: absolute;
			margin-left: -18px;
		}

		#perf-widget-holder .insights li.ok-true::before{
			background-image: url('${serviceURL}/static/images/check.png');
		}

		#perf-widget-holder .insights li.ok-false::before{
			background-image: url('${serviceURL}/static/images/issue.png');
		}

		#perf-widget-holder .insights li a{
			color: rgba(255,255,255,.8);
			border: 0 solid black;
			text-decoration:none;
			display: inline-block;
		}

	`;

	document.head.appendChild(style);


/***/ }
/******/ ]);